"""
Executa todos os métodos numéricos do projeto sobre os datasets de
exemplo da avaliação (Cálculo Numérico - Prof. Lucas Reis).

Rode com: python3 main.py
"""

from interpolacao.lagrange_newton import lagrange, newton
from interpolacao.gregory_newton import gregory_newton
from interpolacao.splines import spline_linear, spline_cubica_natural
from ajuste_curvas.mmq import ajuste_linear, prever
from integracao.newton_cotes import trapezios_repetido, simpson_1_3, simpson_3_8
from integracao.gauss import quadratura_gauss


def linha(titulo):
    print("\n" + "=" * 60)
    print(titulo)
    print("=" * 60)


def main():
    # 1) Lagrange e Newton - drone
    linha("1) Interpolação - Lagrange e Newton (drone)")
    t = [1.0, 2.0, 3.0, 4.0, 5.0]
    y = [1.2, 1.9, 3.2, 5.5, 8.2]
    print(f"Lagrange: y(3.5) = {lagrange(t, y, 3.5):.4f}")
    print(f"Newton:   y(3.5) = {newton(t, y, 3.5):.4f}")

    # 2) Gregory-Newton - data center
    linha("2) Interpolação - Gregory-Newton (data center)")
    x = [10, 20, 30, 40]
    y2 = [45.0, 52.0, 60.0, 71.0]
    print(f"Temperatura estimada em x=25: {gregory_newton(x, y2, 25, h=10):.4f} ºC")

    # 3) Splines - braço robótico
    linha("3) Interpolação - Splines linear e cúbica (braço robótico)")
    tt = [0.0, 1.0, 2.0, 3.0]
    yy = [2.5, 4.5, 3.0, 6.0]
    print(f"Spline Linear: y(1.5) = {spline_linear(tt, yy, 1.5):.4f}")
    print(f"Spline Cúbica Natural: y(1.5) = {spline_cubica_natural(tt, yy, 1.5):.4f}")

    # 4) MMQ - tráfego DEINF
    linha("4) Ajuste de Curvas - MMQ (tráfego DEINF)")
    xd = [8, 9, 10, 11, 12]
    yd = [2.1, 2.8, 3.1, 4.0, 4.8]
    a, b = ajuste_linear(xd, yd)
    print(f"P1(x) = {a:.4f}*x + ({b:.4f})")
    print(f"Previsão para x=13h: {prever(a, b, 13):.4f} mil acessos")

    # 5) Newton-Cotes 3/8 - servidor
    linha("5) Integração - Newton-Cotes / Simpson 3/8 (servidor)")
    v = [10, 15, 12, 8]
    print(f"Total transferido: {simpson_3_8(v, h=2):.4f} MB")

    # 6) Trapézios e Simpson 1/3 - carro elétrico
    linha("6) Integração - Trapézios e Simpson 1/3 (carro elétrico)")
    v2 = [0, 40, 65, 80, 90]
    print(f"Trapézios (repetida): {trapezios_repetido(v2, h=0.5):.4f} km")
    print(f"Simpson 1/3:          {simpson_1_3(v2, h=0.5):.4f} km")

    # 7) Quadratura de Gauss - torque do motor
    linha("7) Integração - Quadratura de Gauss (torque do motor)")

    def f(xv):
        return 5 * xv**3 + xv**2 - 12 * xv + 4

    print(f"n=2 pontos: integral = {quadratura_gauss(f, -1, 1, 2):.4f}")
    print(f"n=3 pontos: integral = {quadratura_gauss(f, -1, 1, 3):.4f}")


if __name__ == "__main__":
    main()
