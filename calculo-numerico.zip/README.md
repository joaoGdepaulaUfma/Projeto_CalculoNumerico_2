# Cálculo Numérico — Projeto Unidade 2

Implementação, em Python puro (sem numpy/scipy), dos métodos numéricos
pedidos na 2ª avaliação da disciplina (Prof. Lucas Reis).

## Estrutura

```
interpolacao/
  lagrange_newton.py   -> Interpolação de Lagrange e Newton (diferenças divididas)
  gregory_newton.py    -> Interpolação de Gregory-Newton (pontos igualmente espaçados)
  splines.py            -> Spline Linear e Spline Cúbica Natural

ajuste_curvas/
  mmq.py                -> Ajuste linear por Mínimos Quadrados (MMQ)

integracao/
  newton_cotes.py       -> Trapézios (repetida), Simpson 1/3 e Simpson 3/8
  gauss.py               -> Quadratura de Gauss (n=2 e n=3)

main.py                 -> Roda todos os métodos sobre os datasets de exemplo do PDF
```

## Como rodar

```bash
python3 main.py
```

Cada módulo também roda individualmente e imprime o resultado do seu
exemplo (ex: `python3 interpolacao/lagrange_newton.py`).

## Resultados obtidos com os datasets do enunciado

| Exercício | Resultado |
|---|---|
| Lagrange / Newton (drone, x=3.5) | 4.2391 m |
| Gregory-Newton (data center, x=25) | 55.75 ºC |
| Spline Linear (t=1.5) | 3.75 cm |
| Spline Cúbica Natural (t=1.5) | 3.675 cm |
| MMQ — reta ajustada | P1(x) = 0.66x − 3.24 |
| MMQ — previsão x=13h | 5.34 mil acessos |
| Simpson 3/8 (servidor) | 74.25 MB |
| Trapézios repetida (carro) | 115.0 km |
| Simpson 1/3 (carro) | 116.6667 km |
| Quadratura de Gauss n=2 (torque) | 8.6667 |
| Quadratura de Gauss n=3 (torque) | 8.6667 |

## Observações sobre a entrega

Este repositório é o ponto de partida. Conforme a dinâmica da avaliação
pede **construção contínua com um commit por aula/método novo**, a partir
daqui os commits devem ser feitos pelo grupo conforme cada método for
estudado em sala — não faz sentido (nem é permitido) simular um
histórico de commits distribuído no tempo.

Grupo (até 3 pessoas): _preencher com os nomes_.
