"""
Ajuste de curvas - Método dos Mínimos Quadrados (MMQ).
Ajuste linear P1(x) = a*x + b, sem numpy/scipy.
"""


def ajuste_linear(x_pontos, y_pontos):
    """
    Calcula os coeficientes a e b da reta P1(x) = a*x + b que melhor
    se ajusta aos pontos, pelo método dos mínimos quadrados.

    Fórmulas fechadas (regressão linear simples):
        a = (n*Sxy - Sx*Sy) / (n*Sxx - Sx^2)
        b = (Sy - a*Sx) / n
    """
    n = len(x_pontos)

    soma_x = sum(x_pontos)
    soma_y = sum(y_pontos)
    soma_xy = sum(x_pontos[i] * y_pontos[i] for i in range(n))
    soma_xx = sum(x**2 for x in x_pontos)

    a = (n * soma_xy - soma_x * soma_y) / (n * soma_xx - soma_x**2)
    b = (soma_y - a * soma_x) / n

    return a, b


def prever(a, b, x):
    """Avalia a reta ajustada a*x + b em um ponto x."""
    return a * x + b


if __name__ == "__main__":
    # Exemplo do slide 9: tráfego de rede no DEINF
    x = [8, 9, 10, 11, 12]
    y = [2.1, 2.8, 3.1, 4.0, 4.8]

    a, b = ajuste_linear(x, y)
    x_alvo = 13
    previsao = prever(a, b, x_alvo)

    print("=== Ajuste de Curvas - MMQ (tráfego DEINF) ===")
    print(f"P1(x) = {a:.4f}*x + ({b:.4f})")
    print(f"Previsão para x={x_alvo}h: {previsao:.4f} mil acessos")
