"""
Interpolação por splines - Linear e Cúbica Natural.
Sistema tridiagonal resolvido por eliminação de Gauss "na mão",
sem numpy/scipy.
"""


def spline_linear(x_pontos, y_pontos, x):
    """
    Interpola x usando splines lineares (reta entre cada par de pontos
    consecutivos).
    """
    n = len(x_pontos)

    for i in range(n - 1):
        if x_pontos[i] <= x <= x_pontos[i + 1]:
            x0, x1 = x_pontos[i], x_pontos[i + 1]
            y0, y1 = y_pontos[i], y_pontos[i + 1]
            return y0 + (y1 - y0) * (x - x0) / (x1 - x0)

    raise ValueError("x fora do intervalo dos pontos conhecidos")


def _resolver_tridiagonal(a, b, c, d):
    """
    Resolve um sistema tridiagonal Ax = d pelo algoritmo de Thomas.
    a: subdiagonal (a[0] não é usado)
    b: diagonal principal
    c: superdiagonal (c[-1] não é usado)
    d: termos independentes
    Retorna a lista solução x.
    """
    n = len(d)
    c_linha = [0.0] * n
    d_linha = [0.0] * n

    c_linha[0] = c[0] / b[0]
    d_linha[0] = d[0] / b[0]

    for i in range(1, n):
        m = b[i] - a[i] * c_linha[i - 1]
        c_linha[i] = c[i] / m if i < n - 1 else 0.0
        d_linha[i] = (d[i] - a[i] * d_linha[i - 1]) / m

    x = [0.0] * n
    x[-1] = d_linha[-1]
    for i in range(n - 2, -1, -1):
        x[i] = d_linha[i] - c_linha[i] * x[i + 1]

    return x


def _coeficientes_spline_cubica_natural(x_pontos, y_pontos):
    """
    Calcula os coeficientes (a, b, c, d) de cada trecho da spline cúbica
    natural: S_i(x) = a_i + b_i*(x-x_i) + c_i*(x-x_i)^2 + d_i*(x-x_i)^3
    """
    n = len(x_pontos) - 1  # número de intervalos
    h = [x_pontos[i + 1] - x_pontos[i] for i in range(n)]

    # Monta o sistema tridiagonal para encontrar os c_i (segunda derivada/2)
    a_diag = [0.0] * (n + 1)
    b_diag = [1.0] * (n + 1)
    c_diag = [0.0] * (n + 1)
    d_termo = [0.0] * (n + 1)

    for i in range(1, n):
        a_diag[i] = h[i - 1]
        b_diag[i] = 2 * (h[i - 1] + h[i])
        c_diag[i] = h[i]
        d_termo[i] = 3 * (
            (y_pontos[i + 1] - y_pontos[i]) / h[i]
            - (y_pontos[i] - y_pontos[i - 1]) / h[i - 1]
        )

    # condições naturais: c_0 = c_n = 0
    c_coef = _resolver_tridiagonal(a_diag, b_diag, c_diag, d_termo)

    a_coef = list(y_pontos)
    b_coef = [0.0] * n
    d_coef = [0.0] * n

    for i in range(n):
        b_coef[i] = (
            (y_pontos[i + 1] - y_pontos[i]) / h[i]
            - h[i] * (2 * c_coef[i] + c_coef[i + 1]) / 3
        )
        d_coef[i] = (c_coef[i + 1] - c_coef[i]) / (3 * h[i])

    return a_coef, b_coef, c_coef, d_coef


def spline_cubica_natural(x_pontos, y_pontos, x):
    """
    Interpola x usando spline cúbica natural.
    """
    n = len(x_pontos) - 1
    a_coef, b_coef, c_coef, d_coef = _coeficientes_spline_cubica_natural(
        x_pontos, y_pontos
    )

    for i in range(n):
        if x_pontos[i] <= x <= x_pontos[i + 1]:
            dx = x - x_pontos[i]
            return (
                a_coef[i]
                + b_coef[i] * dx
                + c_coef[i] * dx**2
                + d_coef[i] * dx**3
            )

    raise ValueError("x fora do intervalo dos pontos conhecidos")


if __name__ == "__main__":
    # Exemplo do slide 8: braço robótico
    t = [0.0, 1.0, 2.0, 3.0]
    y = [2.5, 4.5, 3.0, 6.0]
    t_alvo = 1.5

    print("=== Interpolação - Splines (braço robótico) ===")
    print(f"Spline Linear: y({t_alvo}) = {spline_linear(t, y, t_alvo):.4f}")
    print(f"Spline Cúbica Natural: y({t_alvo}) = {spline_cubica_natural(t, y, t_alvo):.4f}")
