"""
Interpolação polinomial - Métodos de Lagrange e Newton (diferenças divididas).
Implementação sem bibliotecas prontas (apenas Python nativo).
"""


def lagrange(x_pontos, y_pontos, x):
    """
    Interpola o valor de y em x usando o polinômio de Lagrange.

    x_pontos, y_pontos: listas com os pontos conhecidos (mesmo tamanho)
    x: ponto onde queremos estimar y
    """
    n = len(x_pontos)
    resultado = 0.0

    for i in range(n):
        termo = y_pontos[i]
        for j in range(n):
            if j != i:
                termo *= (x - x_pontos[j]) / (x_pontos[i] - x_pontos[j])
        resultado += termo

    return resultado


def _diferencas_divididas(x_pontos, y_pontos):
    """
    Monta a tabela de diferenças divididas de Newton.
    Retorna a lista de coeficientes f[x0], f[x0,x1], f[x0,x1,x2], ...
    """
    n = len(x_pontos)
    # tabela[i][j] guarda a diferença dividida de ordem j começando em x_i
    tabela = [[0.0] * n for _ in range(n)]

    for i in range(n):
        tabela[i][0] = y_pontos[i]

    for j in range(1, n):
        for i in range(n - j):
            tabela[i][j] = (tabela[i + 1][j - 1] - tabela[i][j - 1]) / (
                x_pontos[i + j] - x_pontos[i]
            )

    # coeficientes = primeira linha da tabela
    coeficientes = [tabela[0][j] for j in range(n)]
    return coeficientes


def newton(x_pontos, y_pontos, x):
    """
    Interpola o valor de y em x usando o polinômio de Newton
    (forma das diferenças divididas).
    """
    coeficientes = _diferencas_divididas(x_pontos, y_pontos)
    n = len(coeficientes)

    resultado = coeficientes[0]
    produto_acumulado = 1.0

    for i in range(1, n):
        produto_acumulado *= (x - x_pontos[i - 1])
        resultado += coeficientes[i] * produto_acumulado

    return resultado


if __name__ == "__main__":
    # Exemplo do slide 6: telemetria do drone
    t = [1.0, 2.0, 3.0, 4.0, 5.0]
    y = [1.2, 1.9, 3.2, 5.5, 8.2]
    x_alvo = 3.5

    print("=== Interpolação - Lagrange e Newton (drone) ===")
    print(f"Lagrange: y({x_alvo}) = {lagrange(t, y, x_alvo):.4f}")
    print(f"Newton:   y({x_alvo}) = {newton(t, y, x_alvo):.4f}")
