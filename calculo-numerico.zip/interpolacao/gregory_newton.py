"""
Interpolação polinomial - Fórmula de Gregory-Newton (diferenças finitas
progressivas), para pontos igualmente espaçados.
"""

from math import factorial


def _tabela_diferencas_finitas(y_pontos):
    """
    Monta a tabela de diferenças finitas progressivas.
    tabela[0] = valores originais de y
    tabela[k] = diferenças de ordem k
    """
    n = len(y_pontos)
    tabela = [list(y_pontos)]

    nivel_atual = list(y_pontos)
    for _ in range(1, n):
        proximo_nivel = [
            nivel_atual[i + 1] - nivel_atual[i] for i in range(len(nivel_atual) - 1)
        ]
        tabela.append(proximo_nivel)
        nivel_atual = proximo_nivel

    return tabela


def gregory_newton(x_pontos, y_pontos, x, h=None):
    """
    Interpola y em x usando a fórmula de Gregory-Newton progressiva.
    Requer pontos x igualmente espaçados por um passo h.
    """
    n = len(x_pontos)
    if h is None:
        h = x_pontos[1] - x_pontos[0]

    tabela = _tabela_diferencas_finitas(y_pontos)

    u = (x - x_pontos[0]) / h

    resultado = tabela[0][0]
    produto_u = 1.0

    for k in range(1, n):
        produto_u *= (u - (k - 1))
        diferenca_k = tabela[k][0]
        resultado += (produto_u * diferenca_k) / factorial(k)

    return resultado


if __name__ == "__main__":
    # Exemplo do slide 7: temperatura do data center
    x = [10, 20, 30, 40]
    y = [45.0, 52.0, 60.0, 71.0]
    h = 10
    x_alvo = 25

    resultado = gregory_newton(x, y, x_alvo, h)
    print("=== Interpolação - Gregory-Newton (data center) ===")
    print(f"Temperatura estimada em x={x_alvo}: {resultado:.4f} ºC")
