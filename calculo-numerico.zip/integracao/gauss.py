"""
Integração numérica - Fórmula de Quadratura de Gauss (FQG).
Pontos e pesos fixos para n = 2 e n = 3 no intervalo [-1, 1],
sem numpy/scipy.
"""

# Tabela de pontos (raízes dos polinômios de Legendre) e pesos
_PONTOS_PESOS = {
    2: {
        "raizes": [-1 / (3 ** 0.5), 1 / (3 ** 0.5)],
        "pesos": [1.0, 1.0],
    },
    3: {
        "raizes": [-(3 / 5) ** 0.5, 0.0, (3 / 5) ** 0.5],
        "pesos": [5 / 9, 8 / 9, 5 / 9],
    },
}


def quadratura_gauss(funcao, a, b, n_pontos):
    """
    Calcula a integral de `funcao` no intervalo [a, b] usando a
    Quadratura de Gauss com n_pontos (2 ou 3).

    Faz a mudança de variável do intervalo [a, b] para [-1, 1]:
        x = ((b-a)/2)*t + (b+a)/2
        dx = ((b-a)/2)*dt
    """
    if n_pontos not in _PONTOS_PESOS:
        raise ValueError("Apenas n_pontos = 2 ou 3 estão implementados")

    raizes = _PONTOS_PESOS[n_pontos]["raizes"]
    pesos = _PONTOS_PESOS[n_pontos]["pesos"]

    fator = (b - a) / 2
    deslocamento = (b + a) / 2

    resultado = 0.0
    for t, w in zip(raizes, pesos):
        x = fator * t + deslocamento
        resultado += w * funcao(x)

    return fator * resultado


if __name__ == "__main__":
    # Exemplo do slide 12: torque de um motor
    def f(x):
        return 5 * x**3 + x**2 - 12 * x + 4

    a, b = -1, 1
    resultado_n2 = quadratura_gauss(f, a, b, 2)
    resultado_n3 = quadratura_gauss(f, a, b, 3)

    print("=== Integração numérica - Quadratura de Gauss (torque do motor) ===")
    print(f"n=2 pontos: integral = {resultado_n2:.4f}")
    print(f"n=3 pontos: integral = {resultado_n3:.4f}  (conferência)")
