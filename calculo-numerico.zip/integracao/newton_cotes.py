"""
Integração numérica - Fórmulas de Newton-Cotes:
Regra dos Trapézios (repetida), Simpson 1/3 e Simpson 3/8.
Trabalham diretamente sobre pontos tabelados (x, y) igualmente espaçados.
"""


def trapezios_repetido(y_pontos, h):
    """
    Regra dos trapézios repetida.
    y_pontos: valores de y nos pontos igualmente espaçados
    h: passo entre os pontos
    """
    n = len(y_pontos) - 1  # número de intervalos
    soma = y_pontos[0] + y_pontos[-1]
    soma += 2 * sum(y_pontos[1:-1])
    return (h / 2) * soma


def simpson_1_3(y_pontos, h):
    """
    Regra 1/3 de Simpson. Requer número de intervalos par (n par),
    ou seja, número ímpar de pontos.
    """
    n = len(y_pontos) - 1
    if n % 2 != 0:
        raise ValueError("Simpson 1/3 requer um número par de intervalos")

    soma = y_pontos[0] + y_pontos[-1]
    for i in range(1, n):
        coeficiente = 4 if i % 2 != 0 else 2
        soma += coeficiente * y_pontos[i]

    return (h / 3) * soma


def simpson_3_8(y_pontos, h):
    """
    Regra 3/8 de Simpson. Requer número de intervalos múltiplo de 3.
    """
    n = len(y_pontos) - 1
    if n % 3 != 0:
        raise ValueError("Simpson 3/8 requer um número de intervalos múltiplo de 3")

    soma = y_pontos[0] + y_pontos[-1]
    for i in range(1, n):
        coeficiente = 2 if i % 3 == 0 else 3
        soma += coeficiente * y_pontos[i]

    return (3 * h / 8) * soma


if __name__ == "__main__":
    print("=== Integração numérica - Newton-Cotes ===\n")

    # Exemplo do slide 10: taxa de transferência (Simpson 3/8)
    v = [10, 15, 12, 8]
    h1 = 2
    total_mb = simpson_3_8(v, h1)
    print("-- Servidor: dados transferidos (Simpson 3/8) --")
    print(f"Total transferido: {total_mb:.4f} MB\n")

    # Exemplo do slide 11: velocidade do carro elétrico
    v2 = [0, 40, 65, 80, 90]
    h2 = 0.5
    dist_trapezio = trapezios_repetido(v2, h2)
    dist_simpson = simpson_1_3(v2, h2)
    print("-- Carro elétrico: distância percorrida --")
    print(f"Trapézios (repetida): {dist_trapezio:.4f} km")
    print(f"Simpson 1/3:          {dist_simpson:.4f} km")
